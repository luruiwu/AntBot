#!/usr/bin/env python
#coding=utf-8


i = 0
while (i <= 10):
	i = i + 1
	print i;
